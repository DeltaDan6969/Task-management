/**
 * ShiftTask Firebase & Cloud Backend Configuration
 * Synchronized with Android Project Credentials & Firestore Database
 */
window.__FIREBASE_CONFIG__ = {
  apiKey: "AIzaSyAHPTAlTY1cWoAvHMBHKQ951T7ZgnO0hIM",
  projectId: "gen-lang-client-0968461451",
  authDomain: "gen-lang-client-0968461451.firebaseapp.com",
  storageBucket: "gen-lang-client-0968461451.firebasestorage.app",
  databaseId: "ai-studio-android-shifttas-347ba838-628f-49f4-a473-be4ef8849c02"
};
